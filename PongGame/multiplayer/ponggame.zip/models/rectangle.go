package models

type Rectangle struct {
	PosX, PosY, Width, Height int
}
