package consts

const (
	SampleRate          = 44100
	WordsPerSec         = 2.71828
	SpeedIncreaseFactor = 1.1
	MaxBallSpeed        = 20
)
